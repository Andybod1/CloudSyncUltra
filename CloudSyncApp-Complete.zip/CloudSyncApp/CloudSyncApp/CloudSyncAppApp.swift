//
//  CloudSyncAppApp.swift
//  CloudSyncApp
//
//  Created on 2026-01-10
//

import SwiftUI

@main
struct CloudSyncAppApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    @StateObject private var syncManager = SyncManager.shared
    
    var body: some Scene {
        Settings {
            SettingsView()
                .environmentObject(syncManager)
        }
    }
}

class AppDelegate: NSObject, NSApplicationDelegate {
    var statusBarController: StatusBarController?
    
    func applicationDidFinishLaunching(_ notification: Notification) {
        // Hide dock icon (menu bar app only)
        NSApp.setActivationPolicy(.accessory)
        
        // Setup menu bar
        statusBarController = StatusBarController()
        statusBarController?.setupMenuBar()
        
        // Start monitoring if already configured
        if UserDefaults.standard.bool(forKey: "isConfigured") {
            Task {
                await SyncManager.shared.startMonitoring()
            }
        }
    }
    
    func applicationWillTerminate(_ notification: Notification) {
        SyncManager.shared.stopMonitoring()
    }
}
