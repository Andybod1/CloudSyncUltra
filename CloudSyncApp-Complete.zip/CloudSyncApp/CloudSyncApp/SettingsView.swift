//
//  SettingsView.swift
//  CloudSyncApp
//
//  Settings and configuration UI
//

import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var syncManager: SyncManager
    @State private var selectedTab = 0
    
    var body: some View {
        TabView(selection: $selectedTab) {
            GeneralSettingsView()
                .tabItem {
                    Label("General", systemImage: "gear")
                }
                .tag(0)
            
            AccountSettingsView()
                .tabItem {
                    Label("Account", systemImage: "person.circle")
                }
                .tag(1)
            
            AboutView()
                .tabItem {
                    Label("About", systemImage: "info.circle")
                }
                .tag(2)
        }
        .frame(width: 500, height: 400)
    }
}

struct GeneralSettingsView: View {
    @EnvironmentObject var syncManager: SyncManager
    @State private var localPath: String = ""
    @State private var remotePath: String = ""
    @State private var autoSync: Bool = true
    @State private var syncInterval: Double = 300
    @State private var showingFolderPicker = false
    
    var body: some View {
        Form {
            Section {
                HStack {
                    Text("Local Folder:")
                        .frame(width: 120, alignment: .trailing)
                    
                    TextField("Choose a folder...", text: $localPath)
                        .textFieldStyle(.roundedBorder)
                        .disabled(true)
                    
                    Button("Choose...") {
                        selectFolder()
                    }
                }
                
                HStack {
                    Text("Remote Path:")
                        .frame(width: 120, alignment: .trailing)
                    
                    TextField("e.g., /Documents", text: $remotePath)
                        .textFieldStyle(.roundedBorder)
                }
            } header: {
                Text("Sync Locations")
                    .font(.headline)
            }
            
            Section {
                Toggle("Enable automatic sync", isOn: $autoSync)
                    .padding(.leading, 120)
                
                if autoSync {
                    HStack {
                        Text("Sync interval:")
                            .frame(width: 120, alignment: .trailing)
                        
                        Slider(value: $syncInterval, in: 60...3600, step: 60)
                        
                        Text("\(Int(syncInterval / 60)) min")
                            .frame(width: 60)
                    }
                }
            } header: {
                Text("Sync Settings")
                    .font(.headline)
            }
            
            HStack {
                Spacer()
                Button("Save") {
                    saveSettings()
                }
                .buttonStyle(.borderedProminent)
            }
        }
        .padding()
        .onAppear {
            loadSettings()
        }
    }
    
    private func selectFolder() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = false
        panel.canCreateDirectories = true
        
        if panel.runModal() == .OK {
            localPath = panel.url?.path ?? ""
        }
    }
    
    private func loadSettings() {
        localPath = syncManager.localPath
        remotePath = syncManager.remotePath
        autoSync = syncManager.autoSync
        syncInterval = syncManager.syncInterval
    }
    
    private func saveSettings() {
        syncManager.localPath = localPath
        syncManager.remotePath = remotePath
        syncManager.autoSync = autoSync
        syncManager.syncInterval = syncInterval
        
        Task {
            if syncManager.isMonitoring {
                syncManager.stopMonitoring()
            }
            if autoSync && !localPath.isEmpty {
                await syncManager.startMonitoring()
            }
        }
    }
}

struct AccountSettingsView: View {
    @State private var username: String = ""
    @State private var password: String = ""
    @State private var isConfigured: Bool = false
    @State private var isConfiguring: Bool = false
    @State private var errorMessage: String?
    
    var body: some View {
        Form {
            Section {
                if isConfigured {
                    HStack {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(.green)
                        Text("Proton Drive is connected")
                    }
                    
                    Button("Disconnect") {
                        disconnect()
                    }
                    .foregroundColor(.red)
                } else {
                    HStack {
                        Text("Username:")
                            .frame(width: 120, alignment: .trailing)
                        TextField("user@proton.me", text: $username)
                            .textFieldStyle(.roundedBorder)
                    }
                    
                    HStack {
                        Text("Password:")
                            .frame(width: 120, alignment: .trailing)
                        SecureField("Password", text: $password)
                            .textFieldStyle(.roundedBorder)
                    }
                    
                    if let error = errorMessage {
                        Text(error)
                            .foregroundColor(.red)
                            .font(.caption)
                    }
                    
                    HStack {
                        Spacer()
                        Button("Connect") {
                            Task {
                                await configureProtonDrive()
                            }
                        }
                        .buttonStyle(.borderedProminent)
                        .disabled(username.isEmpty || password.isEmpty || isConfiguring)
                    }
                    
                    if isConfiguring {
                        ProgressView("Connecting...")
                    }
                }
            } header: {
                Text("Proton Drive Account")
                    .font(.headline)
            }
            
            Section {
                Text("Your credentials are stored securely in the macOS Keychain.")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
        .padding()
        .onAppear {
            checkConfiguration()
        }
    }
    
    private func checkConfiguration() {
        isConfigured = RcloneManager.shared.isConfigured()
    }
    
    private func configureProtonDrive() async {
        isConfiguring = true
        errorMessage = nil
        
        do {
            try await SyncManager.shared.configureProtonDrive(
                username: username,
                password: password
            )
            isConfigured = true
            username = ""
            password = ""
        } catch {
            errorMessage = error.localizedDescription
        }
        
        isConfiguring = false
    }
    
    private func disconnect() {
        // Remove rclone config
        let configPath = FileManager.default.urls(
            for: .applicationSupportDirectory,
            in: .userDomainMask
        )[0].appendingPathComponent("CloudSyncApp/rclone.conf")
        
        try? FileManager.default.removeItem(at: configPath)
        UserDefaults.standard.set(false, forKey: "isConfigured")
        isConfigured = false
    }
}

struct AboutView: View {
    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "cloud.fill")
                .font(.system(size: 64))
                .foregroundColor(.blue)
            
            Text("CloudSync")
                .font(.title)
                .fontWeight(.bold)
            
            Text("Version 1.0.0")
                .foregroundColor(.secondary)
            
            Text("A simple and secure cloud sync solution")
                .multilineTextAlignment(.center)
                .foregroundColor(.secondary)
            
            Divider()
                .padding(.vertical)
            
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    Text("Powered by:")
                        .fontWeight(.semibold)
                    Text("rclone")
                }
                
                HStack {
                    Text("Storage:")
                        .fontWeight(.semibold)
                    Text("Proton Drive")
                }
            }
            
            Spacer()
            
            Link("Documentation", destination: URL(string: "https://rclone.org/protondrive/")!)
                .buttonStyle(.bordered)
        }
        .padding()
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

#Preview {
    SettingsView()
        .environmentObject(SyncManager.shared)
}
