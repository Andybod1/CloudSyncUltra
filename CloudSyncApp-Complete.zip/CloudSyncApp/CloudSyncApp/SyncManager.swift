//
//  SyncManager.swift
//  CloudSyncApp
//
//  Coordinates file monitoring and synchronization
//

import Foundation
import Combine

@MainActor
class SyncManager: ObservableObject {
    static let shared = SyncManager()
    
    @Published var syncStatus: SyncStatus = .idle
    @Published var lastSyncTime: Date?
    @Published var currentProgress: SyncProgress?
    @Published var isMonitoring = false
    
    private let rclone = RcloneManager.shared
    private var fileMonitor: FileMonitor?
    private var syncTimer: Timer?
    private var cancellables = Set<AnyCancellable>()
    
    var localPath: String {
        get { UserDefaults.standard.string(forKey: "localPath") ?? "" }
        set { UserDefaults.standard.set(newValue, forKey: "localPath") }
    }
    
    var remotePath: String {
        get { UserDefaults.standard.string(forKey: "remotePath") ?? "" }
        set { UserDefaults.standard.set(newValue, forKey: "remotePath") }
    }
    
    var syncInterval: TimeInterval {
        get { UserDefaults.standard.double(forKey: "syncInterval") != 0 
            ? UserDefaults.standard.double(forKey: "syncInterval") 
            : 300 } // Default 5 minutes
        set { UserDefaults.standard.set(newValue, forKey: "syncInterval") }
    }
    
    var autoSync: Bool {
        get { UserDefaults.standard.bool(forKey: "autoSync") }
        set { UserDefaults.standard.set(newValue, forKey: "autoSync") }
    }
    
    private init() {}
    
    // MARK: - Monitoring
    
    func startMonitoring() async {
        guard !localPath.isEmpty else { return }
        
        isMonitoring = true
        
        // Setup file system monitoring
        fileMonitor = FileMonitor(path: localPath) { [weak self] in
            Task { @MainActor in
                guard let self = self, self.autoSync else { return }
                // Debounce: wait 3 seconds after changes before syncing
                self.scheduleSync(delay: 3.0)
            }
        }
        
        // Setup periodic sync
        if autoSync {
            syncTimer = Timer.scheduledTimer(withTimeInterval: syncInterval, repeats: true) { [weak self] _ in
                Task { @MainActor in
                    await self?.performSync()
                }
            }
        }
        
        // Do initial sync
        await performSync()
    }
    
    func stopMonitoring() {
        isMonitoring = false
        fileMonitor?.stop()
        fileMonitor = nil
        syncTimer?.invalidate()
        syncTimer = nil
        rclone.stopCurrentSync()
    }
    
    private var scheduledSyncTask: Task<Void, Never>?
    
    private func scheduleSync(delay: TimeInterval) {
        scheduledSyncTask?.cancel()
        scheduledSyncTask = Task {
            try? await Task.sleep(nanoseconds: UInt64(delay * 1_000_000_000))
            guard !Task.isCancelled else { return }
            await performSync()
        }
    }
    
    // MARK: - Sync Operations
    
    func performSync(mode: SyncMode = .oneWay) async {
        guard syncStatus != .syncing else { return }
        
        syncStatus = .syncing
        currentProgress = SyncProgress(percentage: 0, speed: "Starting...", status: .syncing)
        
        do {
            let progressStream = try await rclone.sync(
                localPath: localPath,
                remotePath: remotePath,
                mode: mode
            )
            
            for await progress in progressStream {
                currentProgress = progress
                syncStatus = progress.status
            }
            
            syncStatus = .completed
            lastSyncTime = Date()
            
            // Reset to idle after 3 seconds
            try? await Task.sleep(nanoseconds: 3_000_000_000)
            if syncStatus == .completed {
                syncStatus = .idle
            }
            
        } catch {
            syncStatus = .error(error.localizedDescription)
            print("Sync error: \(error)")
        }
    }
    
    func manualSync() async {
        await performSync()
    }
    
    // MARK: - Configuration
    
    func configureProtonDrive(username: String, password: String) async throws {
        try await rclone.setupProtonDrive(username: username, password: password)
        UserDefaults.standard.set(true, forKey: "isConfigured")
    }
    
    func isConfigured() -> Bool {
        rclone.isConfigured()
    }
}

// MARK: - File Monitor

class FileMonitor {
    private var eventStream: FSEventStreamRef?
    private let path: String
    private let onChange: () -> Void
    
    init(path: String, onChange: @escaping () -> Void) {
        self.path = path
        self.onChange = onChange
        start()
    }
    
    private func start() {
        var context = FSEventStreamContext(
            version: 0,
            info: Unmanaged.passUnretained(self).toOpaque(),
            retain: nil,
            release: nil,
            copyDescription: nil
        )
        
        let callback: FSEventStreamCallback = { streamRef, clientCallBackInfo, numEvents, eventPaths, eventFlags, eventIds in
            guard let info = clientCallBackInfo else { return }
            let monitor = Unmanaged<FileMonitor>.fromOpaque(info).takeUnretainedValue()
            monitor.onChange()
        }
        
        let pathsToWatch = [path] as CFArray
        let flags = UInt32(kFSEventStreamCreateFlagUseCFTypes | kFSEventStreamCreateFlagFileEvents)
        
        eventStream = FSEventStreamCreate(
            kCFAllocatorDefault,
            callback,
            &context,
            pathsToWatch,
            FSEventStreamEventId(kFSEventStreamEventIdSinceNow),
            0.5, // latency
            flags
        )
        
        if let stream = eventStream {
            FSEventStreamScheduleWithRunLoop(stream, CFRunLoopGetMain(), CFRunLoopMode.defaultMode.rawValue)
            FSEventStreamStart(stream)
        }
    }
    
    func stop() {
        if let stream = eventStream {
            FSEventStreamStop(stream)
            FSEventStreamInvalidate(stream)
            FSEventStreamRelease(stream)
            eventStream = nil
        }
    }
    
    deinit {
        stop()
    }
}
