//
//  RcloneManager.swift
//  CloudSyncApp
//
//  Manages rclone binary, configuration, and process execution
//

import Foundation

class RcloneManager {
    static let shared = RcloneManager()
    
    private var rclonePath: String
    private var configPath: String
    private var process: Process?
    
    private init() {
        // Look for bundled rclone first, fall back to system rclone
        if let bundledPath = Bundle.main.path(forResource: "rclone", ofType: nil) {
            self.rclonePath = bundledPath
            // Make it executable
            try? FileManager.default.setAttributes(
                [.posixPermissions: 0o755],
                ofItemAtPath: bundledPath
            )
        } else {
            // Use system rclone (assumes installed via homebrew)
            self.rclonePath = "/opt/homebrew/bin/rclone"
        }
        
        // Store config in Application Support
        let appSupport = FileManager.default.urls(
            for: .applicationSupportDirectory,
            in: .userDomainMask
        )[0]
        let appFolder = appSupport.appendingPathComponent("CloudSyncApp", isDirectory: true)
        
        try? FileManager.default.createDirectory(
            at: appFolder,
            withIntermediateDirectories: true
        )
        
        self.configPath = appFolder.appendingPathComponent("rclone.conf").path
    }
    
    // MARK: - Configuration
    
    func isConfigured() -> Bool {
        FileManager.default.fileExists(atPath: configPath)
    }
    
    func setupProtonDrive(username: String, password: String) async throws {
        let process = Process()
        process.executableURL = URL(fileURLWithPath: rclonePath)
        process.arguments = [
            "config", "create",
            "proton",
            "protondrive",
            "username", username,
            "password", password,
            "--config", configPath,
            "--non-interactive"
        ]
        
        let outputPipe = Pipe()
        let errorPipe = Pipe()
        process.standardOutput = outputPipe
        process.standardError = errorPipe
        
        try process.run()
        process.waitUntilExit()
        
        if process.terminationStatus != 0 {
            let errorData = errorPipe.fileHandleForReading.readDataToEndOfFile()
            let errorString = String(data: errorData, encoding: .utf8) ?? "Unknown error"
            throw RcloneError.configurationFailed(errorString)
        }
    }
    
    // MARK: - Sync Operations
    
    func sync(localPath: String, remotePath: String, mode: SyncMode = .oneWay) async throws -> AsyncStream<SyncProgress> {
        return AsyncStream { continuation in
            Task {
                let process = Process()
                process.executableURL = URL(fileURLWithPath: rclonePath)
                
                // Build arguments based on mode
                var args: [String] = []
                
                switch mode {
                case .oneWay:
                    args = [
                        "sync",
                        localPath,
                        "proton:\(remotePath)",
                        "--config", configPath,
                        "--progress",
                        "--stats", "1s",
                        "--transfers", "4",
                        "--checkers", "8",
                        "--verbose"
                    ]
                case .biDirectional:
                    args = [
                        "bisync",
                        localPath,
                        "proton:\(remotePath)",
                        "--config", configPath,
                        "--resilient",
                        "--recover",
                        "--conflict-resolve", "newer",
                        "--conflict-loser", "num",
                        "--verbose",
                        "--max-delete", "50"
                    ]
                }
                
                process.arguments = args
                
                let pipe = Pipe()
                process.standardOutput = pipe
                process.standardError = pipe
                
                // Read output asynchronously
                pipe.fileHandleForReading.readabilityHandler = { handle in
                    let data = handle.availableData
                    if !data.isEmpty {
                        if let output = String(data: data, encoding: .utf8) {
                            if let progress = self.parseProgress(from: output) {
                                continuation.yield(progress)
                            }
                        }
                    }
                }
                
                try process.run()
                self.process = process
                
                process.waitUntilExit()
                
                pipe.fileHandleForReading.readabilityHandler = nil
                continuation.finish()
            }
        }
    }
    
    func listRemoteFiles(remotePath: String) async throws -> [RemoteFile] {
        let process = Process()
        process.executableURL = URL(fileURLWithPath: rclonePath)
        process.arguments = [
            "lsjson",
            "proton:\(remotePath)",
            "--config", configPath
        ]
        
        let outputPipe = Pipe()
        process.standardOutput = outputPipe
        
        try process.run()
        process.waitUntilExit()
        
        let data = outputPipe.fileHandleForReading.readDataToEndOfFile()
        let files = try JSONDecoder().decode([RemoteFile].self, from: data)
        
        return files
    }
    
    func stopCurrentSync() {
        process?.terminate()
        process = nil
    }
    
    // MARK: - Progress Parsing
    
    private func parseProgress(from output: String) -> SyncProgress? {
        // Parse rclone output for progress information
        // Example: "Transferred:   	    1.234 MiB / 10.567 MiB, 12%, 234.5 KiB/s, ETA 30s"
        
        let lines = output.components(separatedBy: .newlines)
        
        for line in lines {
            if line.contains("Transferred:") {
                // Extract transferred, total, percentage, speed
                let components = line.components(separatedBy: ",")
                
                if components.count >= 3 {
                    // Parse percentage
                    let percentageStr = components[1].trimmingCharacters(in: .whitespaces)
                    let percentage = Double(percentageStr.replacingOccurrences(of: "%", with: "")) ?? 0
                    
                    // Parse speed
                    let speedStr = components[2].trimmingCharacters(in: .whitespaces)
                    
                    return SyncProgress(
                        percentage: percentage,
                        speed: speedStr,
                        status: .syncing
                    )
                }
            }
            
            if line.contains("Checks:") {
                return SyncProgress(percentage: 0, speed: "Checking files...", status: .checking)
            }
            
            if line.contains("ERROR") {
                return SyncProgress(percentage: 0, speed: "", status: .error(line))
            }
        }
        
        return nil
    }
}

// MARK: - Supporting Types

enum SyncMode {
    case oneWay
    case biDirectional
}

struct SyncProgress {
    let percentage: Double
    let speed: String
    let status: SyncStatus
}

enum SyncStatus {
    case idle
    case checking
    case syncing
    case completed
    case error(String)
}

struct RemoteFile: Codable {
    let Path: String
    let Name: String
    let Size: Int64
    let MimeType: String
    let ModTime: String
    let IsDir: Bool
}

enum RcloneError: LocalizedError {
    case configurationFailed(String)
    case syncFailed(String)
    case notInstalled
    
    var errorDescription: String? {
        switch self {
        case .configurationFailed(let message):
            return "Configuration failed: \(message)"
        case .syncFailed(let message):
            return "Sync failed: \(message)"
        case .notInstalled:
            return "rclone is not installed. Please install via: brew install rclone"
        }
    }
}
