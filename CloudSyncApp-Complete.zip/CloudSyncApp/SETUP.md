# CloudSync - Detailed Setup Guide

This guide walks you through setting up CloudSync from scratch.

## Prerequisites Installation

### 1. Install Homebrew (if not already installed)

```bash
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

### 2. Install rclone

```bash
brew install rclone
```

Verify installation:
```bash
rclone version
```

Expected output:
```
rclone v1.65.0
- os/version: darwin 14.x (64 bit)
- os/kernel: 23.x.x (arm64 or x86_64)
- os/type: darwin
- os/arch: arm64 (or amd64)
- go/version: go1.21.x
```

### 3. Configure rclone with Proton Drive (Manual Setup)

If you prefer to configure rclone manually before using the app:

```bash
rclone config
```

Follow the interactive prompts:
1. Choose: `n` (New remote)
2. Name: `proton`
3. Storage: Enter number for `protondrive`
4. Username: Your Proton email
5. Password: Your Proton password
6. 2FA (if enabled): Enter your 2FA code
7. Confirm: `y`
8. Quit: `q`

Test the connection:
```bash
rclone lsd proton:
```

## Building the App

### Method 1: Using Xcode (Recommended)

1. **Open the project:**
   ```bash
   cd CloudSyncApp
   open CloudSyncApp.xcodeproj
   ```

2. **Configure signing (if needed):**
   - Select the project in navigator
   - Select "CloudSyncApp" target
   - Go to "Signing & Capabilities" tab
   - Select your Team or use "Sign to Run Locally"

3. **Build & Run:**
   - Press `⌘R` or click the Play button
   - The app will compile and launch
   - Look for the cloud icon in your menu bar

### Method 2: Command Line Build

```bash
cd CloudSyncApp

# Debug build
xcodebuild -project CloudSyncApp.xcodeproj \
           -scheme CloudSyncApp \
           -configuration Debug \
           build

# The app will be at:
# build/Debug/CloudSyncApp.app

# Run it:
open build/Debug/CloudSyncApp.app
```

### Method 3: Release Build

```bash
# Build for release
xcodebuild -project CloudSyncApp.xcodeproj \
           -scheme CloudSyncApp \
           -configuration Release \
           build

# The app will be at:
# build/Release/CloudSyncApp.app

# Copy to Applications
cp -r build/Release/CloudSyncApp.app /Applications/
```

## First-Time Configuration

### Step 1: Launch the App

After building, the app appears as a cloud icon in your menu bar (top-right corner).

If you don't see it:
- Hold `⌘` and drag menu bar icons to rearrange
- It may be hidden under the "two dots" icon (>>) on the right

### Step 2: Open Preferences

Click the cloud icon → "Preferences..." (or press `⌘,`)

### Step 3: Connect Proton Drive Account

1. Go to the **Account** tab
2. Enter your credentials:
   - **Username**: your.email@proton.me
   - **Password**: Your Proton account password
3. Click **Connect**
4. Wait for "Proton Drive is connected" message

**Troubleshooting:**
- If connection fails, verify credentials in browser: https://drive.proton.me
- Check if 2FA is enabled (may need app password)
- Ensure stable internet connection

### Step 4: Configure Sync Locations

1. Go to the **General** tab
2. **Local Folder:**
   - Click "Choose..."
   - Select the folder you want to sync (e.g., ~/Documents/ProtonSync)
   - Create a new folder if needed
3. **Remote Path:**
   - Enter the path on Proton Drive (e.g., `/Backup` or `/Documents`)
   - Use `/` for root of your Proton Drive
4. **Sync Settings:**
   - Enable "Enable automatic sync" ✓
   - Set sync interval (default: 5 minutes)
5. Click **Save**

### Step 5: Initial Sync

After saving settings:
1. Watch the menu bar icon
2. Icon changes to ↻ (syncing arrow)
3. First sync may take longer (uploading all files)
4. Icon changes to ✓ when complete

**Monitoring Progress:**
- Click the menu bar icon to see status
- Shows: "Syncing: X%"
- Shows: "Last sync: X minutes ago"

## Verification

### Verify Local to Remote Sync

1. Create a test file in your local sync folder:
   ```bash
   echo "Test sync" > ~/Documents/ProtonSync/test.txt
   ```

2. Wait 3 seconds (debounce delay) + sync time

3. Check Proton Drive:
   - Visit https://drive.proton.me
   - Navigate to your remote path
   - Verify `test.txt` appears

### Verify Sync is Running

```bash
# Check rclone processes
ps aux | grep rclone

# Check app logs (in Console.app)
# Filter by process: CloudSyncApp
```

## Permissions Setup

### Grant Full Disk Access (if needed)

Some folders require special permissions:

1. Open **System Settings**
2. Go to **Privacy & Security**
3. Click **Full Disk Access**
4. Click the `+` button
5. Navigate to CloudSyncApp.app
6. Add it to the list
7. Restart the app

### Allow Network Connections

First time the app runs, macOS may ask:
- "CloudSyncApp would like to access the network"
- Click **Allow**

## Advanced Setup

### Bundling rclone with the App

To create a standalone app that doesn't require homebrew rclone:

1. **Download rclone binary:**
   ```bash
   cd /tmp
   wget https://downloads.rclone.org/rclone-current-osx-arm64.zip
   unzip rclone-current-osx-arm64.zip
   ```

2. **Add to Xcode project:**
   - Drag `rclone` binary into Xcode
   - Check "Copy items if needed"
   - Add to target: CloudSyncApp

3. **Update RcloneManager.swift:**
   Already configured to check for bundled version first!

### Launch at Login

Add to System Settings → General → Login Items:

```bash
# Via command line
osascript -e 'tell application "System Events" to make login item at end with properties {path:"/Applications/CloudSyncApp.app", hidden:false}'
```

Or manually:
1. System Settings → General → Login Items
2. Click `+` button
3. Select CloudSyncApp.app
4. Check "Hide" to start in menu bar only

### Custom Sync Intervals

Edit in Settings or directly:

```bash
defaults write com.yourcompany.CloudSyncApp syncInterval 180  # 3 minutes
```

### Exclude Patterns

Add to `RcloneManager.swift` sync arguments:

```swift
"--exclude", "*.tmp",
"--exclude", ".DS_Store",
"--exclude", "node_modules/**",
```

## Troubleshooting Setup

### "rclone: command not found"

```bash
# Install rclone
brew install rclone

# Check installation
which rclone
# Should show: /opt/homebrew/bin/rclone

# If using Intel Mac:
# /usr/local/bin/rclone
```

### "Build Failed" in Xcode

1. **Clean build folder:**
   - Product → Clean Build Folder (⌘⇧K)

2. **Update deployment target:**
   - Project settings → Deployment Target → macOS 13.0

3. **Check Swift version:**
   - Should be Swift 5.9+

### "App Won't Launch"

1. **Check Console.app:**
   - Open Console.app
   - Filter: CloudSyncApp
   - Look for crash logs

2. **Reset preferences:**
   ```bash
   defaults delete com.yourcompany.CloudSyncApp
   ```

3. **Check permissions:**
   - System Settings → Privacy & Security
   - Verify CloudSyncApp has necessary permissions

### "Sync Not Working"

1. **Verify rclone config:**
   ```bash
   rclone config show
   # Should show [proton] section
   ```

2. **Test rclone manually:**
   ```bash
   rclone ls proton:
   ```

3. **Check logs:**
   - Menu bar → Preferences → About
   - Look for error messages

4. **Reset rclone config:**
   ```bash
   rm -rf ~/Library/Application\ Support/CloudSyncApp/rclone.conf
   # Then reconfigure in app
   ```

### "Permission Denied" Errors

Grant permissions:
```bash
# Give rclone execute permission
chmod +x /opt/homebrew/bin/rclone

# Or for bundled version
chmod +x CloudSyncApp.app/Contents/Resources/rclone
```

## Testing the Setup

### Comprehensive Test Script

```bash
#!/bin/bash

echo "=== CloudSync Setup Test ==="

# 1. Check rclone
echo "
1. Checking rclone..."
if command -v rclone &> /dev/null; then
    echo "✓ rclone installed"
    rclone version
else
    echo "✗ rclone not found"
    exit 1
fi

# 2. Check config
echo "
2. Checking rclone config..."
if rclone config show | grep -q "proton"; then
    echo "✓ Proton Drive configured"
else
    echo "✗ Proton Drive not configured"
fi

# 3. Test connection
echo "
3. Testing Proton Drive connection..."
if rclone lsd proton: &> /dev/null; then
    echo "✓ Connection successful"
else
    echo "✗ Connection failed"
fi

# 4. Check app
echo "
4. Checking app..."
if [ -d "CloudSyncApp.app" ] || [ -d "/Applications/CloudSyncApp.app" ]; then
    echo "✓ CloudSyncApp found"
else
    echo "✗ CloudSyncApp not found"
fi

echo "
=== Test Complete ==="
```

Save as `test-setup.sh` and run:
```bash
chmod +x test-setup.sh
./test-setup.sh
```

## Next Steps

After setup is complete:

1. **Review Settings** - Adjust sync interval and options
2. **Monitor First Sync** - Watch progress in menu bar
3. **Test File Sync** - Create/edit files and verify sync
4. **Enable Launch at Login** - For automatic startup
5. **Read README.md** - For usage and advanced features

## Support

If you encounter issues not covered here:

1. Check the main README.md
2. Review rclone docs: https://rclone.org/protondrive/
3. Check Proton Drive help: https://proton.me/support/drive
4. Review Console.app logs for errors

---

**Setup Guide Version**: 1.0  
**Last Updated**: January 2026
