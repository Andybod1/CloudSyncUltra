# CloudSync - Quick Start

Get up and running in 5 minutes!

## Prerequisites (One-time)

```bash
# 1. Install Homebrew (if not installed)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# 2. Install rclone
brew install rclone

# 3. Have a Proton Drive account
# Sign up at: https://proton.me/drive (free tier available)
```

## Quick Install

```bash
# Option 1: Automatic installation
./install.sh

# Option 2: Manual steps
./build.sh
cp -r build/Build/Products/Release/CloudSyncApp.app /Applications/
```

## First Run

1. **Launch CloudSync**
   - Find the cloud icon in your menu bar (top-right)
   - May be hidden under ">>" icon

2. **Open Preferences** (⌘,)
   - Click cloud icon → "Preferences..."

3. **Connect Proton Drive**
   - Go to "Account" tab
   - Enter: username@proton.me
   - Enter: your password
   - Click "Connect"

4. **Setup Sync Folder**
   - Go to "General" tab
   - Local: Click "Choose..." and select folder
   - Remote: Enter path like `/Backup`
   - Enable "Enable automatic sync"
   - Click "Save"

5. **Done!**
   - Watch the menu bar icon
   - ☁️ = Idle
   - ↻ = Syncing
   - ✓ = Up to date

## Common Tasks

### Manual Sync
```
Menu bar icon → "Sync Now" (or ⌘S)
```

### Pause Syncing
```
Menu bar icon → "Pause Sync"
```

### Open Sync Folder
```
Menu bar icon → "Open Sync Folder"
```

### Change Settings
```
Menu bar icon → "Preferences..." (⌘,)
```

## Troubleshooting

### "rclone not found"
```bash
brew install rclone
which rclone  # Should show /opt/homebrew/bin/rclone
```

### "Connection failed"
- Check Proton Drive credentials at https://drive.proton.me
- Verify internet connection
- Check if 2FA is enabled (may need app password)

### "Sync not working"
- Verify folder permissions
- Check available Proton Drive storage
- Look for errors in menu: Click icon to see status

### Reset Everything
```bash
# Remove config
rm -rf ~/Library/Application\ Support/CloudSyncApp

# Remove preferences
defaults delete com.yourcompany.CloudSyncApp

# Restart app
```

## Quick Commands

### Test rclone connection
```bash
rclone lsd proton:
```

### Manual sync (without app)
```bash
rclone sync /path/to/local/folder proton:/path/to/remote
```

### List remote files
```bash
rclone ls proton:/
```

## Keyboard Shortcuts

- `⌘S` - Sync Now (when menu open)
- `⌘,` - Preferences
- `⌘Q` - Quit CloudSync

## Tips

1. **Start Small** - Test with a small folder first
2. **Monitor First Sync** - Initial sync may take time
3. **Check Storage** - Ensure enough space on Proton Drive
4. **Use Subfolders** - Organize with remote paths like `/Photos`, `/Documents`
5. **Exclude Files** - See DEVELOPMENT.md for exclude patterns

## Need More Help?

- **Detailed Setup**: Read `SETUP.md`
- **Development**: Read `DEVELOPMENT.md`
- **Full Docs**: Read `README.md`
- **rclone Help**: https://rclone.org/protondrive/

## Status Icons

| Icon | Meaning |
|------|---------|
| ☁️ | Idle - No sync in progress |
| ↻ | Syncing - Transfer in progress |
| ✓ | Complete - Last sync successful |
| ⚠️ | Error - Check menu for details |

---

**Quick Start Version**: 1.0  
**Last Updated**: January 2026
